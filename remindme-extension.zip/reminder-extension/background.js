// Background Service Worker — RemindMe Extension

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const data = await chrome.storage.local.get('reminders');
  const reminders = data.reminders || [];
  const reminder = reminders.find(r => r.id === alarm.name);

  if (reminder) {
    chrome.notifications.create(alarm.name, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '⏰ RemindMe',
      message: reminder.text,
      priority: 2,
      requireInteraction: true
    });

    // Mark as triggered
    const updated = reminders.map(r =>
      r.id === alarm.name ? { ...r, triggered: true } : r
    );
    await chrome.storage.local.set({ reminders: updated });

    // Update badge
    updateBadge(updated);
  }
});

chrome.notifications.onClicked.addListener(async (notifId) => {
  const data = await chrome.storage.local.get('reminders');
  const reminders = data.reminders || [];
  const updated = reminders.map(r =>
    r.id === notifId ? { ...r, dismissed: true } : r
  );
  await chrome.storage.local.set({ reminders: updated });
  updateBadge(updated);
  chrome.notifications.clear(notifId);
});

async function updateBadge(reminders) {
  const active = reminders.filter(r => r.triggered && !r.dismissed).length;
  if (active > 0) {
    chrome.action.setBadgeText({ text: String(active) });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}
