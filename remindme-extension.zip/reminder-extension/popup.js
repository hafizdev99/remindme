// popup.js — RemindMe Extension

const SITE_URL = 'https://remindme-extension.netlify.app'; // update with real URL

// — TABS —
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'list') renderList();
  });
});

// — SNACK —
function showSnack(msg, color = '#4ade80') {
  const s = document.getElementById('snack');
  s.textContent = msg;
  s.style.background = color;
  s.classList.add('show');
  setTimeout(() => s.classList.remove('show'), 2200);
}

// — DEFAULT DATETIME —
function setDefaultTime() {
  const dt = new Date(Date.now() + 10 * 60 * 1000);
  const pad = n => String(n).padStart(2, '0');
  const val = `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}T${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
  document.getElementById('reminderTime').value = val;
}
setDefaultTime();

// — ADD REMINDER —
document.getElementById('addBtn').addEventListener('click', async () => {
  const text = document.getElementById('reminderText').value.trim();
  const timeVal = document.getElementById('reminderTime').value;
  const recurrence = document.getElementById('recurrence').value;

  if (!text) return showSnack('Please enter reminder text', '#f06292');
  if (!timeVal) return showSnack('Please pick a date & time', '#f06292');

  const when = new Date(timeVal).getTime();
  if (when <= Date.now()) return showSnack('Time must be in the future', '#f06292');

  const id = 'r_' + Date.now();
  const data = await chrome.storage.local.get('reminders');
  const reminders = data.reminders || [];

  const reminder = { id, text, when, recurrence, triggered: false, dismissed: false };
  reminders.push(reminder);
  await chrome.storage.local.set({ reminders });

  // Schedule alarm
  if (recurrence === 'none') {
    chrome.alarms.create(id, { when });
  } else if (recurrence === 'hourly') {
    chrome.alarms.create(id, { when, periodInMinutes: 60 });
  } else if (recurrence === 'daily') {
    chrome.alarms.create(id, { when, periodInMinutes: 1440 });
  } else if (recurrence === 'weekly') {
    chrome.alarms.create(id, { when, periodInMinutes: 10080 });
  } else if (recurrence === 'weekdays') {
    chrome.alarms.create(id, { when, periodInMinutes: 1440 }); // daily, filtered in bg
  }

  document.getElementById('reminderText').value = '';
  setDefaultTime();
  document.getElementById('recurrence').value = 'none';

  showSnack('✓ Reminder set!');
  updateBadgeUI(reminders);
});

// — RENDER LIST —
async function renderList() {
  const data = await chrome.storage.local.get(['reminders', 'autoDismiss']);
  let reminders = data.reminders || [];
  const autoDismiss = data.autoDismiss !== false ? false : false; // default off
  const container = document.getElementById('reminderList');

  if (reminders.length === 0) {
    container.innerHTML = `<div class="list-empty"><div class="empty-icon">🔔</div>No reminders yet.<br/>Head to Add tab to create one.</div>`;
    return;
  }

  // Sort: upcoming first, past last
  reminders.sort((a, b) => a.when - b.when);

  container.innerHTML = '';
  reminders.forEach(r => {
    const isPast = r.when < Date.now() && !r.recurrence !== 'none';
    const div = document.createElement('div');
    div.className = 'reminder-item' + (r.triggered ? ' triggered' : '') + (isPast && r.recurrence === 'none' ? ' past' : '');

    const dt = new Date(r.when);
    const timeStr = dt.toLocaleString('en-GB', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' });

    const tagLabel = r.triggered ? 'FIRED' : r.recurrence !== 'none' ? r.recurrence.toUpperCase() : 'ONCE';
    const tagClass = r.triggered ? 'reminder-tag fired' : 'reminder-tag';

    div.innerHTML = `
      <div class="reminder-dot"></div>
      <div class="reminder-info">
        <div class="reminder-text" title="${escHtml(r.text)}">${escHtml(r.text)}</div>
        <div class="reminder-meta">
          <span>${timeStr}</span>
          <span class="${tagClass}">${tagLabel}</span>
        </div>
      </div>
      <button class="del-btn" data-id="${r.id}" title="Delete">✕</button>
    `;
    container.appendChild(div);
  });

  container.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      chrome.alarms.clear(id);
      const d = await chrome.storage.local.get('reminders');
      const updated = (d.reminders || []).filter(r => r.id !== id);
      await chrome.storage.local.set({ reminders: updated });
      updateBadgeUI(updated);
      renderList();
      showSnack('Reminder deleted');
    });
  });
}

function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// — BADGE —
async function updateBadgeUI(reminders) {
  if (!reminders) {
    const d = await chrome.storage.local.get('reminders');
    reminders = d.reminders || [];
  }
  const active = reminders.filter(r => r.triggered && !r.dismissed).length;
  const el = document.getElementById('badgeCount');
  if (active > 0) {
    el.textContent = active;
    el.classList.add('show');
  } else {
    el.classList.remove('show');
  }
}

// — SETTINGS —
async function loadSettings() {
  const d = await chrome.storage.local.get(['notifEnabled','badgeEnabled','autoDismiss']);
  setToggle('toggleNotif', d.notifEnabled !== false);
  setToggle('toggleBadge', d.badgeEnabled !== false);
  setToggle('toggleAutoDismiss', d.autoDismiss === true);
}

function setToggle(id, on) {
  const el = document.getElementById(id);
  if (on) el.classList.add('on'); else el.classList.remove('on');
}

function bindToggle(id, key) {
  document.getElementById(id).addEventListener('click', async function() {
    const isOn = this.classList.toggle('on');
    await chrome.storage.local.set({ [key]: isOn });
  });
}

bindToggle('toggleNotif', 'notifEnabled');
bindToggle('toggleBadge', 'badgeEnabled');
bindToggle('toggleAutoDismiss', 'autoDismiss');

document.getElementById('clearAll').addEventListener('click', async () => {
  if (!confirm('Delete all reminders?')) return;
  const d = await chrome.storage.local.get('reminders');
  const reminders = d.reminders || [];
  reminders.forEach(r => chrome.alarms.clear(r.id));
  await chrome.storage.local.set({ reminders: [] });
  chrome.action.setBadgeText({ text: '' });
  document.getElementById('badgeCount').classList.remove('show');
  showSnack('All reminders cleared');
  renderList();
});

document.getElementById('visitSite').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: SITE_URL });
});

// — INIT —
loadSettings();
updateBadgeUI();
